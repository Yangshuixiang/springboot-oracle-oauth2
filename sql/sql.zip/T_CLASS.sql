/*
 Navicat Premium Data Transfer

 Source Server         : yang-oracle
 Source Server Type    : Oracle
 Source Server Version : 190000
 Source Host           : localhost:1521
 Source Schema         : YANG

 Target Server Type    : Oracle
 Target Server Version : 190000
 File Encoding         : 65001

 Date: 08/12/2020 20:13:25
*/


-- ----------------------------
-- Table structure for T_CLASS
-- ----------------------------
DROP TABLE "YANG"."T_CLASS";
CREATE TABLE "YANG"."T_CLASS" (
  "CLASS_ID" NUMBER(11) VISIBLE NOT NULL ,
  "CLASS_NAME" VARCHAR2(255 BYTE) VISIBLE ,
  "TEACHER_MUSTER" VARCHAR2(255 BYTE) VISIBLE ,
  "MARK" VARCHAR2(255 BYTE) VISIBLE 
)
TABLESPACE "USERS"
LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT
;

-- ----------------------------
-- Records of T_CLASS
-- ----------------------------
INSERT INTO "YANG"."T_CLASS" VALUES ('1', '小一班', '张老师', '1');
INSERT INTO "YANG"."T_CLASS" VALUES ('2', '小二班', '李老师', '2');
INSERT INTO "YANG"."T_CLASS" VALUES ('3', '小三班', '李老师', '2');
INSERT INTO "YANG"."T_CLASS" VALUES ('4', '中一班', '李老师', '2');
INSERT INTO "YANG"."T_CLASS" VALUES ('5', '中二班', '李老师', '2');
INSERT INTO "YANG"."T_CLASS" VALUES ('6', '中三班', '李老师', '2');
INSERT INTO "YANG"."T_CLASS" VALUES ('7', '大一班', '陈老师', NULL);
INSERT INTO "YANG"."T_CLASS" VALUES ('8', '大二班', '吴老师', NULL);
INSERT INTO "YANG"."T_CLASS" VALUES ('9', '大三班', '魏老师', NULL);

-- ----------------------------
-- Primary Key structure for table T_CLASS
-- ----------------------------
ALTER TABLE "YANG"."T_CLASS" ADD CONSTRAINT "SYS_C007494" PRIMARY KEY ("CLASS_ID");
