/*
 Navicat Premium Data Transfer

 Source Server         : yang-oracle
 Source Server Type    : Oracle
 Source Server Version : 190000
 Source Host           : localhost:1521
 Source Schema         : YANG

 Target Server Type    : Oracle
 Target Server Version : 190000
 File Encoding         : 65001

 Date: 08/12/2020 20:11:35
*/


-- ----------------------------
-- Table structure for OAUTH_ROLE
-- ----------------------------
DROP TABLE "YANG"."OAUTH_ROLE";
CREATE TABLE "YANG"."OAUTH_ROLE" (
  "ID" NUMBER(20) VISIBLE NOT NULL ,
  "ROLE_CODE" NVARCHAR2(20) VISIBLE ,
  "ROLE_NAME" NVARCHAR2(20) VISIBLE ,
  "CREATE_BY" NUMBER(20) VISIBLE ,
  "CREATE_TIME" DATE VISIBLE ,
  "UPDATE_BY" NUMBER(20) VISIBLE ,
  "UPDATE_TIME" DATE VISIBLE 
)
TABLESPACE "USERS"
LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT
;

-- ----------------------------
-- Records of OAUTH_ROLE
-- ----------------------------
INSERT INTO "YANG"."OAUTH_ROLE" VALUES ('1293177755318456322', 'admin', '管理员', NULL, TO_DATE('2020-08-11 21:29:38', 'SYYYY-MM-DD HH24:MI:SS'), NULL, TO_DATE('2020-08-11 21:29:38', 'SYYYY-MM-DD HH24:MI:SS'));
INSERT INTO "YANG"."OAUTH_ROLE" VALUES ('1293356939856674817', 'visitor', '访客', NULL, TO_DATE('2020-08-12 09:21:39', 'SYYYY-MM-DD HH24:MI:SS'), NULL, TO_DATE('2020-08-12 09:21:39', 'SYYYY-MM-DD HH24:MI:SS'));

-- ----------------------------
-- Primary Key structure for table OAUTH_ROLE
-- ----------------------------
ALTER TABLE "YANG"."OAUTH_ROLE" ADD CONSTRAINT "SYS_C007512" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table OAUTH_ROLE
-- ----------------------------
ALTER TABLE "YANG"."OAUTH_ROLE" ADD CONSTRAINT "SYS_C007508" CHECK ("ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;
ALTER TABLE "YANG"."OAUTH_ROLE" ADD CONSTRAINT "SYS_C007521" CHECK ("ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;
