/*
 Navicat Premium Data Transfer

 Source Server         : yang-oracle
 Source Server Type    : Oracle
 Source Server Version : 190000
 Source Host           : localhost:1521
 Source Schema         : YANG

 Target Server Type    : Oracle
 Target Server Version : 190000
 File Encoding         : 65001

 Date: 08/12/2020 20:12:15
*/


-- ----------------------------
-- Table structure for OAUTH_USER_ROLE
-- ----------------------------
DROP TABLE "YANG"."OAUTH_USER_ROLE";
CREATE TABLE "YANG"."OAUTH_USER_ROLE" (
  "ID" NUMBER(20) VISIBLE NOT NULL ,
  "USER_ID" NUMBER(20) VISIBLE ,
  "ROLE_ID" NUMBER(20) VISIBLE 
)
TABLESPACE "USERS"
LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT
;
COMMENT ON COLUMN "YANG"."OAUTH_USER_ROLE"."USER_ID" IS '用户id';
COMMENT ON COLUMN "YANG"."OAUTH_USER_ROLE"."ROLE_ID" IS '角色id';

-- ----------------------------
-- Records of OAUTH_USER_ROLE
-- ----------------------------
INSERT INTO "YANG"."OAUTH_USER_ROLE" VALUES ('1293178327694151682', '1293177353705459713', '1293177755318456322');
INSERT INTO "YANG"."OAUTH_USER_ROLE" VALUES ('1293357301908996097', '1293356708595335170', '1293356939856674817');

-- ----------------------------
-- Primary Key structure for table OAUTH_USER_ROLE
-- ----------------------------
ALTER TABLE "YANG"."OAUTH_USER_ROLE" ADD CONSTRAINT "SYS_C007514" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table OAUTH_USER_ROLE
-- ----------------------------
ALTER TABLE "YANG"."OAUTH_USER_ROLE" ADD CONSTRAINT "SYS_C007510" CHECK ("ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;
ALTER TABLE "YANG"."OAUTH_USER_ROLE" ADD CONSTRAINT "SYS_C007518" CHECK ("ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;
