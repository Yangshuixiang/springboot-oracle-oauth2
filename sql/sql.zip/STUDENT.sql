/*
 Navicat Premium Data Transfer

 Source Server         : yang-oracle
 Source Server Type    : Oracle
 Source Server Version : 190000
 Source Host           : localhost:1521
 Source Schema         : YANG

 Target Server Type    : Oracle
 Target Server Version : 190000
 File Encoding         : 65001

 Date: 08/12/2020 20:13:41
*/


-- ----------------------------
-- Table structure for STUDENT
-- ----------------------------
DROP TABLE "YANG"."STUDENT";
CREATE TABLE "YANG"."STUDENT" (
  "USER_ID" VARCHAR2(50 BYTE) VISIBLE NOT NULL ,
  "NAME" VARCHAR2(255 BYTE) VISIBLE ,
  "NICK_NAME" VARCHAR2(255 BYTE) VISIBLE ,
  "CLASS_ID" NUMBER(11) VISIBLE ,
  "MARK" VARCHAR2(255 BYTE) VISIBLE ,
  "GUARDIAN" VARCHAR2(255 BYTE) VISIBLE 
)
TABLESPACE "USERS"
LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT
;

-- ----------------------------
-- Primary Key structure for table STUDENT
-- ----------------------------
ALTER TABLE "YANG"."STUDENT" ADD CONSTRAINT "SYS_C007493" PRIMARY KEY ("USER_ID");

-- ----------------------------
-- Checks structure for table STUDENT
-- ----------------------------
ALTER TABLE "YANG"."STUDENT" ADD CONSTRAINT "SYS_C007492" CHECK ("USER_ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;

-- ----------------------------
-- Indexes structure for table STUDENT
-- ----------------------------
CREATE INDEX "YANG"."CLASS_ID"
  ON "YANG"."STUDENT" ("CLASS_ID" ASC)
  LOGGING
  TABLESPACE "USERS"
  VISIBLE
PCTFREE 10
INITRANS 2
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
  FLASH_CACHE DEFAULT
)
   USABLE;
