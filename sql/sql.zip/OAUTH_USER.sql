/*
 Navicat Premium Data Transfer

 Source Server         : yang-oracle
 Source Server Type    : Oracle
 Source Server Version : 190000
 Source Host           : localhost:1521
 Source Schema         : YANG

 Target Server Type    : Oracle
 Target Server Version : 190000
 File Encoding         : 65001

 Date: 08/12/2020 20:12:02
*/


-- ----------------------------
-- Table structure for OAUTH_USER
-- ----------------------------
DROP TABLE "YANG"."OAUTH_USER";
CREATE TABLE "YANG"."OAUTH_USER" (
  "ID" NUMBER(20) VISIBLE NOT NULL ,
  "ACCOUNT" NVARCHAR2(30) VISIBLE ,
  "USER_NAME" NVARCHAR2(20) VISIBLE ,
  "PASSWORD" NVARCHAR2(100) VISIBLE ,
  "PHONE" NVARCHAR2(11) VISIBLE ,
  "GENDER" NUMBER(4) VISIBLE ,
  "STATUS" NUMBER(4) VISIBLE ,
  "DEL_FLAG" NUMBER(4) VISIBLE ,
  "CREATE_BY" NUMBER(20) VISIBLE ,
  "CREATE_TIME" DATE VISIBLE ,
  "UPDATE_BY" NUMBER(20) VISIBLE ,
  "UPDATE_TIME" DATE VISIBLE 
)
TABLESPACE "USERS"
LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT
;

-- ----------------------------
-- Records of OAUTH_USER
-- ----------------------------
INSERT INTO "YANG"."OAUTH_USER" VALUES ('1293177353705459713', 'admin', '管理员', '$2a$10$zctpRXk8AMnvnQuUMbbQeOvz3NHYU7Fg3s4f1m30DmYxSvkwy2WBW', '13866666666', '1', '0', '0', NULL, TO_DATE('2020-08-13 17:26:28', 'SYYYY-MM-DD HH24:MI:SS'), NULL, TO_DATE('2020-08-13 17:26:28', 'SYYYY-MM-DD HH24:MI:SS'));
INSERT INTO "YANG"."OAUTH_USER" VALUES ('1293356708595335170', 'test', '普通用户', '$2a$10$rTPd80G2ffBJekzJ5SylRecqBNtG9RvByMgDn5wUIkgMmlAKsCugC', '13866666666', '1', '0', '0', NULL, TO_DATE('2020-08-12 10:43:15', 'SYYYY-MM-DD HH24:MI:SS'), NULL, TO_DATE('2020-08-12 10:43:15', 'SYYYY-MM-DD HH24:MI:SS'));

-- ----------------------------
-- Checks structure for table OAUTH_USER
-- ----------------------------
ALTER TABLE "YANG"."OAUTH_USER" ADD CONSTRAINT "SYS_C007525" CHECK ("ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;
